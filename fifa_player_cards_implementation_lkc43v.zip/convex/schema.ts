import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  players: defineTable({
    name: v.string(),
    team: v.string(),
    nationality: v.string(),
    jerseyNumber: v.number(),
    age: v.number(),
    imageUrl: v.string(),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
