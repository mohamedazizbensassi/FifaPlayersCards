import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("players").collect();
  },
});

export const add = mutation({
  args: {
    name: v.string(),
    team: v.string(),
    nationality: v.string(),
    jerseyNumber: v.number(),
    age: v.number(),
    imageUrl: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("players", args);
  },
});
