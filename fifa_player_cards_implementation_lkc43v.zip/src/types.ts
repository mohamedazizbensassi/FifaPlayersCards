import { Doc, Id } from "../convex/_generated/dataModel";

export type Player = Doc<"players"> & {
  name: string;
  team: string;
  nationality: string;
  jerseyNumber: number;
  age: number;
  imageUrl: string;
};
