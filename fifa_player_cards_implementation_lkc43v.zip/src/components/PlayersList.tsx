import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { PlayerCard } from "./PlayerCard";

export function PlayersList() {
  const players = useQuery(api.players.list) || [];
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {players.map((player) => (
        <PlayerCard key={player._id} player={player} />
      ))}
    </div>
  );
}
