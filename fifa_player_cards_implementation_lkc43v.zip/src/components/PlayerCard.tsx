import { Player } from "../types";

interface PlayerCardProps {
  player: Player;
}

export function PlayerCard({ player }: PlayerCardProps) {
  const { name, team, nationality, jerseyNumber, age, imageUrl } = player;
  
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="h-48 overflow-hidden">
        <img 
          src={imageUrl || 'https://via.placeholder.com/300'} 
          alt={name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-xl font-bold">{name}</h3>
          <span className="text-2xl font-bold">#{jerseyNumber}</span>
        </div>
        <div className="space-y-1 text-gray-600">
          <p>Team: {team}</p>
          <p>Nationality: {nationality}</p>
          <p>Age: {age}</p>
        </div>
      </div>
    </div>
  );
}
