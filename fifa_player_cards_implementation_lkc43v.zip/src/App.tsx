import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { PlayersList } from "./components/PlayersList";
import { Toaster } from "sonner";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">FIFA Player Cards</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <Authenticated>
            <PlayersList />
          </Authenticated>
          <Unauthenticated>
            <div className="text-center">
              <h1 className="text-4xl font-bold mb-4">FIFA Player Cards</h1>
              <p className="text-xl text-gray-600 mb-8">Sign in to view players</p>
              <SignInForm />
            </div>
          </Unauthenticated>
        </div>
      </main>
      <Toaster />
    </div>
  );
}
